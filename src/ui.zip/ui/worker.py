import time
import traceback
import numpy as np
import imageio.v2 as imageio
from pathlib import Path
from PyQt6.QtCore import QThread, pyqtSignal

# 引入项目核心模块
# 请确保你的项目根目录在 PYTHONPATH 中，或者从 src 包导入
from src.scenarios import make_env, load_config


class SimulationWorker(QThread):
    """
    后台仿真线程
    职责：
    1. 接收临时配置文件路径
    2. 运行仿真循环
    3. 采集绘图所需的数据 (距离、时间等)
    4. 生成 GIF 动画
    5. 将结果回传给主界面
    """

    # 信号定义
    # finished: 仿真成功完成，传回一个包含结果数据的字典
    finished = pyqtSignal(dict)
    # progress: 进度百分比 (0-100)
    progress = pyqtSignal(int)
    # failed: 仿真出错，传回错误信息字符串
    failed = pyqtSignal(str)

    def __init__(self, cfg_path: str):
        """
        :param cfg_path: 临时配置文件的绝对路径 (str)
        """
        super().__init__()
        self.cfg_path = cfg_path
        self._is_running = True  # 用于控制停止

    def run(self):
        env = None
        try:
            # 1. 加载配置
            # 注意：这里的 cfg_path 已经是包含了用户修改参数的 temp_tad.yaml
            cfg = load_config(self.cfg_path)

            # 2. 创建环境
            env = make_env(config=cfg)
            env.reset()

            # 3. 初始化数据记录容器 (用于结果页画图)
            logs = {
                "time": [],  # 时间轴
                "dist_AT": [],  # 攻击者-目标 距离
                "dist_DA": [],  # 防御者-攻击者 距离
                "success": False,  # 是否拦截成功
                "gif_path": ""  # GIF 保存路径
            }

            # 4. 准备 GIF 录制
            gif_frames = []
            save_gif = getattr(cfg, 'save_gif', True)  # 默认为 True
            # 从配置读取步数，默认 300
            max_steps = int(getattr(cfg, 'episode_length', 300))

            # 5. 开始仿真循环
            for step in range(max_steps):
                # 响应停止请求
                if not self._is_running:
                    break

                # --- 物理步进 ---
                env.step()

                # --- 数据采集 ---
                # 获取当前时间
                current_time = step * env.world.dt
                logs["time"].append(current_time)

                # 获取三方位置
                # 假设 agents 列表顺序为: [Target, Attacker, Defender]
                # 这是 TAD 场景的标准顺序，如果你的代码有变动，请根据实际情况调整索引
                try:
                    agents = env.world.agents
                    t_pos = agents[0].state.p_pos  # Target
                    a_pos = agents[1].state.p_pos  # Attacker
                    d_pos = agents[2].state.p_pos  # Defender

                    # 计算欧氏距离
                    dist_at = np.linalg.norm(a_pos - t_pos)
                    dist_da = np.linalg.norm(d_pos - a_pos)

                    logs["dist_AT"].append(float(dist_at))
                    logs["dist_DA"].append(float(dist_da))
                except IndexError:
                    # 防止某些特殊情况 agent 数量不对
                    pass

                # --- 渲染画面 ---
                if save_gif:
                    # mode='rgb_array' 返回一个列表，我们取第一个视角的图像
                    frame = env.render(mode="rgb_array")[0]
                    gif_frames.append(frame)

                # --- 更新进度条 ---
                progress_val = int((step / max_steps) * 100)
                self.progress.emit(progress_val)

            # 6. 循环结束后的处理
            env.close()

            # 判定胜负 (简单示例：如果 Defender 与 Attacker 的最小距离小于拦截半径)
            # 你也可以读取 world.is_caught 等标志位
            intercept_radius = getattr(env.world, 'intercept_radius', 0.5)
            if logs["dist_DA"]:
                min_dist = min(logs["dist_DA"])
                logs["success"] = min_dist < intercept_radius

            # 7. 保存 GIF 文件
            if save_gif and len(gif_frames) > 0 and self._is_running:
                # 确定保存目录
                gif_dir_name = getattr(cfg, 'gif_dir', 'gifs')
                gif_dir = Path(gif_dir_name)
                if not gif_dir.is_absolute():
                    gif_dir = Path.cwd() / gif_dir

                gif_dir.mkdir(parents=True, exist_ok=True)

                # 生成带时间戳的文件名
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                gif_filename = f"render_{timestamp}.gif"
                save_path = gif_dir / gif_filename

                # 使用 imageio 保存
                # duration=0.05 对应 20fps，可根据 dt 调整
                imageio.mimsave(str(save_path), gif_frames, duration=0.05)

                logs["gif_path"] = str(save_path)
                print(f"[Worker] GIF Saved to: {save_path}")

            # 8. 发送完成信号
            if self._is_running:
                self.finished.emit(logs)

        except Exception as e:
            # 捕获所有异常并打印堆栈，方便调试
            traceback.print_exc()
            self.failed.emit(str(e))
        finally:
            # 确保环境被关闭
            if env:
                try:
                    env.close()
                except:
                    pass

    def stop(self):
        """外部调用此方法以强制停止仿真"""
        self._is_running = False