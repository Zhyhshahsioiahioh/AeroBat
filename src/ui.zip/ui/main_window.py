# src/ui/main_window.py
from PyQt6.QtWidgets import QMainWindow, QStackedWidget, QMessageBox, QWidget, QVBoxLayout, QLabel, QProgressBar
from PyQt6.QtCore import Qt
from pathlib import Path

from src.ui.pages.home import HomePage
from src.ui.pages.config import ParameterPage
from src.ui.pages.result import ResultPage
from src.ui.worker import SimulationWorker

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AeroBat Simulation Platform")
        self.resize(1000, 700)
        
        # 加载样式表
        style_path = Path(__file__).parent / "styles.qss"
        if style_path.exists():
            with open(style_path, "r", encoding="utf-8") as f:
                self.setStyleSheet(f.read())

        # 中心控件：堆叠窗口
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        
        # 初始化页面
        self.init_pages()

    def init_pages(self):
        # 1. 首页
        self.home_page = HomePage()
        self.home_page.scenario_selected.connect(self.go_to_config)
        self.stack.addWidget(self.home_page)
        
        # 2. 仿真加载页 (简单做一个进度条页面)
        self.loading_page = QWidget()
        l_layout = QVBoxLayout()
        l_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.progress_label = QLabel("正在进行物理仿真计算...")
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedWidth(400)
        l_layout.addWidget(self.progress_label)
        l_layout.addWidget(self.progress_bar)
        self.loading_page.setLayout(l_layout)
        self.stack.addWidget(self.loading_page)
        
        # 3. 结果页
        self.result_page = ResultPage()
        self.result_page.go_home.connect(self.go_home)
        self.stack.addWidget(self.result_page)
        
        # 4. 配置页 (动态加载)
        self.config_page = None

    def go_to_config(self, scenario_name):
        # 这里目前只处理 'tad'，以后可以扩展
        if scenario_name == "tad":
            cfg_path = Path(__file__).parents[2] / "config" / "tad.yaml"
            self.config_page = ParameterPage(str(cfg_path))
            self.config_page.start_sim.connect(self.start_simulation)
            self.config_page.back_home.connect(self.go_home)
            self.stack.addWidget(self.config_page)
            self.stack.setCurrentWidget(self.config_page)

    def start_simulation(self, positions):
        self.stack.setCurrentWidget(self.loading_page)
        self.progress_bar.setValue(0)
        
        # 启动后台线程
        cfg_path = Path(__file__).parents[2] / "config" / "tad.yaml"
        self.worker = SimulationWorker(cfg_path, positions)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.finished.connect(self.show_results)
        self.worker.failed.connect(self.show_error)
        self.worker.start()

    def show_results(self, logs):
        # 仿真完成，切换到结果页并绘图
        self.result_page.update_data(logs)
        self.stack.setCurrentWidget(self.result_page)
        # 可以在这里弹窗提示GIF路径
        # QMessageBox.information(self, "完成", f"GIF已保存: {logs['gif_path']}")

    def show_error(self, err_msg):
        QMessageBox.critical(self, "错误", f"仿真出错: {err_msg}")
        self.go_home()

    def go_home(self):
        self.stack.setCurrentWidget(self.home_page)
        # 清理 worker
        if hasattr(self, 'worker'):
            self.worker = None