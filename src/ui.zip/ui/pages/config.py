import yaml
import shutil
from pathlib import Path
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QDoubleSpinBox, QGroupBox, QPushButton, QScrollArea, QMessageBox)
from PyQt6.QtCore import Qt, pyqtSignal


class ParameterPage(QWidget):
    start_sim = pyqtSignal(str)  # 传出的是临时 YAML 的路径
    back_home = pyqtSignal()

    def __init__(self, template_cfg_path: str, parent=None):
        super().__init__(parent)
        self.template_path = Path(template_cfg_path)
        # 临时文件路径：与模板同目录，名字加前缀
        self.temp_path = self.template_path.parent / f"temp_{self.template_path.name}"
        self.groups = {}

        # 1. 确保模板存在
        if not self.template_path.exists():
            QMessageBox.critical(self, "错误", f"找不到模板文件: {self.template_path}")
            return

        # 2. 加载原始数据用于显示默认值
        with open(self.template_path, 'r', encoding='utf-8') as f:
            self.raw_data = yaml.safe_load(f)

        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        # 滚动区域
        scroll = QScrollArea()
        scroll_content = QWidget()
        form_layout = QVBoxLayout(scroll_content)

        roles = ["target", "attacker", "defender"]
        agent_params = self.raw_data.get('agent_params', {})

        for role in roles:
            role_data = agent_params.get(role, {})
            init_pos = role_data.get('init_pos', [0, 0, 0])

            group = QGroupBox(role.capitalize())
            h_layout = QHBoxLayout()
            spins = []
            for i, axis in enumerate(['X', 'Y', 'Z']):
                h_layout.addWidget(QLabel(f"{axis}:"))
                spin = QDoubleSpinBox()
                spin.setRange(-500, 500)
                spin.setValue(float(init_pos[i]))
                spins.append(spin)
                h_layout.addWidget(spin)

            group.setLayout(h_layout)
            self.groups[role] = spins
            form_layout.addWidget(group)

        form_layout.addStretch()
        scroll.setWidget(scroll_content)
        scroll.setWidgetResizable(True)
        layout.addWidget(scroll)

        # 按钮
        btn_layout = QHBoxLayout()
        btn_start = QPushButton("保存并开始仿真")
        btn_start.clicked.connect(self._on_start)
        btn_layout.addWidget(btn_start)
        layout.addLayout(btn_layout)

    def _on_start(self):
        # 1. 修改数据字典
        for role, spins in self.groups.items():
            new_pos = [s.value() for s in spins]
            self.raw_data['agent_params'][role]['init_pos'] = new_pos

        # 2. 写入临时文件
        try:
            with open(self.temp_path, 'w', encoding='utf-8') as f:
                yaml.dump(self.raw_data, f, default_flow_style=False)

            # 3. 发射信号，告诉主界面读取这个 temp_path
            self.start_sim.emit(str(self.temp_path))
        except Exception as e:
            QMessageBox.critical(self, "错误", f"写入配置文件失败: {e}")